function Task(check,id, name, desc,date,color,url,status) {
    this.check='False';
    this.id = id;
    this.name = name;
    this.desc = desc;
    this.date = date;
    this.color = color;
    this.url = url;
    this.status=status;

  }
  export default Task;